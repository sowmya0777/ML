from flask import Flask, render_template, request
import numpy as np
import pickle

app = Flask(__name__)

model = pickle.load(open('model.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        features = [float(x) for x in request.form.values()]
        final_features = np.array([features])

        prediction = model.predict(final_features)[0]
        result = "High Risk (Default)" if prediction == 1 else "Low Risk (No Default)"

        return render_template('result.html', prediction_text=result)
    except:
        return "Error in input data"

if __name__ == "__main__":
    app.run(debug=True)
